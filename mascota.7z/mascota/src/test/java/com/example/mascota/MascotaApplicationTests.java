package com.example.mascota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MascotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
