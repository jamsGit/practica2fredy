package com.example.mascota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MascotApplication {

	public static void main(String[] args) {
		SpringApplication.run(MascotApplication.class, args);
	}

}
